package com.xuezhi.qa_service.domain.entity;

public class General {
    private String title;

    private String generalDescription;

    public General(String title, String generalDescription) {
        this.title = title;
        this.generalDescription = generalDescription;
    }
}
