package com.xuezhi.hystrix_dashboard;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HystrixDashboardApplicationTests {

    @Test
    void contextLoads() {
    }

}
